import './App.css';
import RouteDefs from './components/RouteDefs';
import Header from './components/Header';
import Footer from './components/Footer';

function App() {
  return (
    <div className="App">
      <Header/>
      <RouteDefs/>
      <Footer/>
    </div>
  );
}

export default App;
