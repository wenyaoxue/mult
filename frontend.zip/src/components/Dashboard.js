import { useEffect, useState } from "react"
import AppOwnerDashboard from "./dashboards/ownerspec/AppOwnerDashboard"
import AdminDashboard from "./dashboards/adminspec/AdminDashboard"
import UserDashboard from "./dashboards/userspec/UserDashboard"
import './Dashboard.css'
import Button from '@mui/material/Button';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import apireqs from "./APIReqs";

function Dashboard(props) {
    const [home, setHome] = useState(<div>Please wait, currently unable to reach the dashboard controlling service...</div>)

    const changedashboard = () => {
        console.log("CHANGE DASHBOARD")
        let key = localStorage.getItem('mLpXcs')
        if (key != '' && key != null) {
            apireqs.getUser(key).then((res)=> {
                if (res.data.isUser == "true")
                    setHome(<UserDashboard />)
                else if (res.data.isAdmin =="true")
                    setHome(<AdminDashboard />)
                else
                    setHome(<AppOwnerDashboard />)

            }).catch((res)=>console.log("Get all failed", res))
        }
        else
            setHome(<div className="Back">
                <h1 id="pageName" style={{fontSize: 70}}>Welcome!</h1>
                <h3 style={{color: 'white', fontSize: 'large', fontStyle: "italic"}}>We have a curated a selection of carefully chosen movies for your viewing pleasure across several multiplexes in your area.<br></br>Come and join us!</h3>
                <ThemeProvider theme={theme}>
                <Button color="primary" variant="contained" sx={{m: 5, minWidth: 100}}><a href="/login">Login</a></Button>
                <Button color="primary" variant="contained" sx={{m: 5}}><a href="/register">Register</a></Button>
                </ThemeProvider>
            </div>)
    }


    useEffect(changedashboard, [])

    const theme = createTheme({
        palette: {
            primary: {
              main: '#800000',
            }
          },
      });

    return (
        <div>{home}</div>
    )
}

export default Dashboard