import {BrowserRouter, Route, Routes} from 'react-router-dom'
import Login from './authenticate/Login'
import Register from './authenticate/Register'
import ForgotPw from './authenticate/ForgotPw'
import ResetPw from './authenticate/ResetPw'
import ShowTime from './dashboards/ShowTime'
import Dashboard from './Dashboard'
import { useEffect, useState } from 'react'

function RouteDefs(props) {
    return <BrowserRouter>
        <Routes>
            <Route path='/' exact={true} element={<Dashboard/>}/>
            <Route path='/login' element={<Login/>}/>
            <Route path='/register' Component={Register}/>
            <Route path='/forgot' Component={ForgotPw}/>
            <Route path="/showtime/:id" Component={ShowTime}/>
        </Routes>
    </BrowserRouter>
}

export default RouteDefs