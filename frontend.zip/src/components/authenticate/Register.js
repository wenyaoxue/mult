import * as React from 'react';
import TextField from '@mui/material/TextField';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import Button from '@mui/material/Button';
import { Paper } from '@mui/material';
import './Register.css'
import apireqs from '.././APIReqs'
import { createTheme, ThemeProvider } from '@mui/material/styles';

function Register(props) {
    const [securityQuestion, setSecQ] = React.useState('');
    const changeSecQ = (event) => {
        setSecQ(event.target.value);
    };
    const [isUser, setIsU] = React.useState(false);
    const [isAdmin, setIsA] = React.useState(false);
    const [isOwner, setIsO] = React.useState(false);
    const changeType = (event) => {
        setIsU((event.target.value == "tpU").toString())
        setIsA((event.target.value == "tpA").toString())
        setIsO((event.target.value == "tpO").toString())
    };


    const register = (e) => {
        e.preventDefault();

        let checkEmpty = ["un", "pw", "em", "sa"]
        let submit = true
        for (let i = 0; i < checkEmpty.length; i++)
            if (document.getElementById(checkEmpty[i]).value == "") {
                document.getElementById("v" + checkEmpty[i]).innerHTML = "Please fill out this field"
                submit = false
            }
        if (securityQuestion == '')
            document.getElementById('vsq').innerHTML = "Please select a security question"
        if (!(isUser || isAdmin || isOwner))
            document.getElementById('vt').innerHTML = "Please select a profile type"
        if (!submit)
            return
        let username = document.getElementById("un").value
        let password = document.getElementById("pw").value
        let email = document.getElementById("em").value
        let answer = document.getElementById("sa").value
        const user = { username, password, email, securityQuestion, answer, isUser, isAdmin, isOwner }
        console.log("post to createuser", user)

        apireqs.registerUser(user).then((res) => {
            console.log("registered", res.data)
            localStorage.setItem('mLpXcs', res.data.userId)
            window.location.href = "/"
        }).catch((res) => console.log("Create user failed", res))

    }
    const theme = createTheme({
        palette: {
            primary: {
                main: '#800000',
            }
        },
    });
    return (
        <div id="main">
            <ThemeProvider theme={theme}>
                <Paper elevation={3} sx={{ m: 1, minWidth: 600, minHeight: 550 }}>
                    <h1>Register</h1>
                    <form>

                        <TextField id="un" label="Username" variant="outlined" sx={{ m: 1, minWidth: 225 }} size="small" />
                        <div id="vun"></div>
                        <TextField id="pw" label="Password" type="password" autoComplete="current-password" sx={{ m: 1, minWidth: 225 }} size="small" />
                        <div id="vpw"></div>
                        <TextField id="em" label="Email" variant="outlined" sx={{ m: 1, minWidth: 225 }} size="small" />
                        <div id="vem"></div>

                        <FormControl sx={{ m: 1, minWidth: 225 }} size="small">
                            <InputLabel id="demo-simple-select-label">Security Question</InputLabel>
                            <Select
                                labelId="sq"
                                id="sq"
                                label="Security Question"
                                autoWidth
                                onChange={changeSecQ}
                            >
                                <MenuItem value={"maiden"}>What is your mother's maiden name?</MenuItem>
                                <MenuItem value={"boss"}>What is the name of your first boss?</MenuItem>
                                <MenuItem value={"street"}>What street was your childhood home on?</MenuItem>
                            </Select>
                            <div id="vsq"></div>
                        </FormControl>
                        <br></br>
                        <TextField id="sa" label="Answer" variant="outlined" size="small" />
                        <div id="vsa"></div>
                        <FormControl sx={{ m: 1, minWidth: 225 }} size="small">
                            <InputLabel id="demo-simple-select-label">User Type</InputLabel>
                            <Select
                                labelId="demo-simple-select-label"
                                id="type"
                                label="User Type"
                                width="20"
                                onChange={changeType}
                            >
                                <MenuItem value={"tpU"} id="tpU">User</MenuItem>
                                <MenuItem value={"tpA"} id="tpA">Admin</MenuItem>
                                <MenuItem value={"tpO"} id="tpO">App Owner</MenuItem>
                            </Select>
                            <div id="vt"></div>
                        </FormControl>

                        <br></br>
                        <Button id="reg" variant="contained" sx={{ m: 1, minWidth: 225 }} onClick={(e) => register(e)}>Register</Button>
                        <div><a href="/login" className="mainLinks">Already registered? Log in</a></div>
                    </form>
                </Paper>
            </ThemeProvider>
        </div>
    );
}

export default Register