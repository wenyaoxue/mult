import { Paper } from '@mui/material';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import './Register.css'
import apireqs from '.././APIReqs'
import { createTheme, ThemeProvider } from '@mui/material/styles';

function Login(props) {

    const login = (e) => {
        e.preventDefault();

        let checkEmpty = ["un", "pw"]
        let submit = true
        for (let i = 0; i < checkEmpty.length; i++)
            if (document.getElementById(checkEmpty[i]).value == "") {
                document.getElementById("v" + checkEmpty[i]).innerHTML = "Please fill out this field"
                submit = false
            }

        if (!submit)
            return
        let username = document.getElementById("un").value
        let password = document.getElementById("pw").value
        let user = { username, password }
        console.log("post to loginuser", user)
        apireqs.loginUser(user).then(
            (res) => {
                console.log(res)
                if (res.data) {
                    document.getElementById("loginfail").innerHTML = "Logging in..."
                    console.log("login success", res.data)
                    localStorage.setItem('mLpXcs', res.data.userId)
                    window.location.href = "/"
                }
                else
                    document.getElementById("loginfail").innerHTML = "Login credentials are not correct"

            }
        ).catch((res) => {
            document.getElementById("loginfail").innerHTML = res.message
            console.log(res)
        })
    }
    const theme = createTheme({
        palette: {
            primary: {
                main: '#800000',
            }
        },
    });
    return (
        <div id="main">
            <ThemeProvider theme={theme}>
                <Paper elevation={3} sx={{ m: 1, minWidth: 500, minHeight: 400 }}>
                    <h1>Login</h1>
                    <form>
                        <TextField id="un" label="Username" variant="outlined" sx={{ m: 1, minWidth: 225 }} size="small" />
                        <div id="vun"></div>
                        <TextField id="pw" label="Password" type="password" autoComplete="current-password" sx={{ m: 1, minWidth: 225 }} size="small" />
                        <div id="vpw"></div>
                        <div id="loginfail"></div>
                    </form>
                    <Button id="log" onClick={login} variant="contained" sx={{ m: 1, minWidth: 225 }}>Login</Button>
                    <br></br>
                    <div><a href="/forgot" className="mainLinks">Forgot your password?</a></div>
                    <div><a href="/register" className="mainLinks">Don't have an account? Register</a></div>
                </Paper>
            </ThemeProvider>
        </div>
    );

}

export default Login