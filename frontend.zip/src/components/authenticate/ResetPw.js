import { TextField } from "@mui/material"
import Button from '@mui/material/Button';
import { Paper } from "@mui/material"
import './Register.css'
import { createTheme, ThemeProvider } from '@mui/material/styles';
import apireqs from '.././APIReqs'

function ResetPw(props) {
    const resetPw = (e) => {
        if (document.getElementById("newpw").value == document.getElementById("newpw2").value) {
            //update user table
            let newu = {'email':props.email, 'password':document.getElementById('newpw').value}
            apireqs.resetPw(newu).then(
                (res)=>{
                    document.getElementById("resetResult").innerHTML = "Reset successful!"
                    console.log(res.data)
                    localStorage.setItem('mLpXcs', res.data.userId)
                    window.location.href="/"       
                }
            ).catch(
                (res) => {
                    document.getElementById("resetResult").innerHTML =res.message
                }
            )
        } else {
            document.getElementById("resetResult").innerHTML = "New passwords don't match"
        }
    }
    const theme = createTheme({
        palette: {
            primary: {
              main: '#800000',
            }
          },
      });
    return (
        <div id="main">
            <ThemeProvider theme={theme}>
            <Paper id="reset" elevation={5} sx={{ m: 1, height: 250, width: 500}}>
            <h2 id="resetTitle" style={{backgroundColor: '#800000', borderRadius:3, paddingBottom: 20, color: 'white'}}>Reset Password</h2>
            <br></br>
            <TextField id="newpw" label="New Password" variant="standard" size="small" 
                sx={{m: 1, maxWidth: 180}}
                style={{display:'inline-block'}}
                />
            <TextField id="newpw2" label="Re-enter New Password" variant="standard" size="small"
                sx={{m: 1, maxWidth: 180}}
                style={{display:'inline-block'}}
                />
            <br/>
            <br></br>
            <br></br>
            <Button id="rest" size="small" variant="contained" onClick={(e) => resetPw(e)}
                style={{display:'inline-block'}}>Reset Password</Button>
            <div id="resetResult"></div>
            </Paper>
            </ThemeProvider>
        </div>
    );
}

export default ResetPw

//<input id="newpw" /><br />
//<input id="newpw2" /><br />
//<button onClick={(e) => resetPw(e)}>Reset password</button>