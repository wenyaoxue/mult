import { useState } from "react"
import "../.././css/general.css"
import ResetPw from "./ResetPw"
import apireqs from '.././APIReqs'
import { createTheme, ThemeProvider } from '@mui/material/styles';
import { Button } from "@mui/material";
import { Paper } from "@mui/material";

function ForgotPw(props) {
    const [user, setUser] = useState()
    const [secQStr, setSecQStr] = useState('')
    const findAcc = (e) => {
        e.preventDefault()
        let user = { 'email': document.getElementById("recEmail").value }

        apireqs.getByEmail(document.getElementById("recEmail").value).then(
            (res) => {
                console.log(res)
                if (res.data != '') {
                    document.getElementById("enteremail").classList.add("hidden")
                    document.getElementById("secCheck").classList.remove("hidden")
                    switch (res.data.securityQuestion) {
                        case "maiden": setSecQStr("What is your mother's maiden name?"); break;
                        case "boss": setSecQStr("What is the name of your first boss?"); break;
                        case "street": setSecQStr("What street was your childhood home on?"); break;
                        default: setSecQStr("unknown security question [" + res.data.securityQuestion + "]")
                    }
                    setUser(res.data)
                    document.getElementById('vem').innerHTML = user.email
                }
                else {
                    document.getElementById("vem").innerHTML = "No account has been registered with that email"
                }
            }
        ).catch(
            (res) => {
                console.log("getQByEmail failed", res)
                document.getElementById("vem").innerHTML = res.message
            }
        )
    }

    const checkSecQ = (e) => {
        e.preventDefault()
        if (document.getElementById("secA").value == user.answer) {
            document.getElementById("enterseca").classList.add("hidden")
            document.getElementById("secFail").innerHTML = "Security check passed"
            setReset(<ResetPw email={user.email} />)
        }
        else {
            document.getElementById("secFail").innerHTML = "Security check failed"
        }
    }

    const [reset, setReset] = useState(<div></div>)

    const theme = createTheme({
        palette: {
            primary: {
                main: '#800000',
            }
        },
    });

    return <ThemeProvider theme={theme}>
        <div id="recAcc" style={{ display: 'flex', justifyContent: 'center' }}>
            <Paper elevation={3} sx={{ m: 1, minWidth: 700, maxWidth: 800, minHeight: 200, paddingTop: "30px" }}>
                <h2>Forgot your password?</h2>
                <div id="enteremail">
                    Email: <input id="recEmail" />
                    <Button onClick={(e) => findAcc(e)} variant="contained" sx={{ m: 1, minWidth: 100 }}>Search</Button>
                </div>
                <div id="vem" style={{color: 'black', fontWeight: 'bold'}}></div>

                <div id="secCheck" class="hidden" >
                    <h2>{secQStr}</h2>
                    <div id="enterseca">
                        <input id="secA" />
                        <Button onClick={(e) => { checkSecQ(e) }} variant="contained" sx={{ m: 1, minWidth: 100 }}>Submit</Button>
                    </div>
                    <div id="secFail" style={{color: 'green', paddingBottom: 30, fontWeight: 'bold'}}></div>
                </div>
            </Paper>
        </div>



        {reset}
    </ThemeProvider>
}
export default ForgotPw