import { useEffect, useState } from "react"
import AddShowTime from "./adminspec/AddShowTime"
import MvShowtimes from "./MvShowtimes"
import './adminspec/AdminDashboard.css'
import Button from '@mui/material/Button';
import AddBoxIcon from '@mui/icons-material/AddBox';
import apireqs from '.././APIReqs'
import LocationOnIcon from '@mui/icons-material/LocationOn';
import { Paper } from "@mui/material";
import RemoveCircleIcon from '@mui/icons-material/RemoveCircle';

function Multiplex(props) {
    const [showtimes, setShowtimes] = useState([])
    useEffect(() => {
        apireqs.getShowtimesGroupedAt(props.mult.multiplexId).then(
            (res) => {
                setShowtimes(
                    Object.entries(res.data).map((pair) => {
                        return { 'movieId': pair[0], 'showtimes': pair[1] }
                    })
                )
            }
        )
    }, [])

    const [newShowTime, setNewShowTime] = useState(<div></div>)
    const addShowTime = () => {
        //update multiplex table, showtimes table
        console.log("Add Showtime Function Called")
        setNewShowTime(<AddShowTime setThis={setNewShowTime} multId={props.mult.multiplexId} refresh={props.init} />)
    }
    const deleteAllShowtimes = () => {
        for (let i = 0; i < showtimes.length; i++)
            for (let j = 0; j < showtimes[i].showtimes.length; j++) {
                apireqs.delShowtime(showtimes[i].showtimes[j].showtimeId).then(
                    (res) => window.location.href = "/"
                ).catch(
                    (err) => console.log(err.message)
                )

            }
    }
    const deleteMultiplex = () => {
        if (showtimes.length == 0) {
            apireqs.delMultiplex(props.mult.multiplexId).then(
                (res) => window.location.href = "/"
            ).catch((res) => console.log("delete multiplex failed", res.message))
            return
        }
        for (let i = 0; i < showtimes.length; i++)
            for (let j = 0; j < showtimes[i].showtimes.length; j++) {
                apireqs.delShowtime(showtimes[i].showtimes[j].showtimeId).then(
                    (res) => {
                        window.location.href = "/"
                        if (i == showtimes.length - 1 && j == showtimes[i].length)
                            apireqs.delMultiplex(props.mult.multiplexId).then(
                                (res) => window.location.href = "/"
                            ).catch((res) => console.log("delete multiplex failed", res.message))
                    }
                ).catch(
                    (err) => console.log(err.message)
                )

            }
    }

    return <div key={props.mult.multiplexI} id="mainMult">
        <Paper  id='adminMain' elevation={5} sx={{maxWidth:1600, minWidth: 445,borderRadius: "36px", alignContent: "center"}}>
            <div id="indMult">
                <div style={{fontWeight: "bold", fontSize: "large", textTransform: "uppercase", marginRight: 20, marginLeft: 20, marginTop: 0, paddingTop: 0}}>{props.mult.name} <LocationOnIcon /> {props.mult.address} ID#{props.mult.multiplexId}</div>
                <Button id="addtime"
                    size="small"
                    variant="contained"
                    startIcon={<AddBoxIcon />}
                    onClick={addShowTime} sx={{ marginRight: "20px", marginTop: "20px" }}>Showtime</Button>
                <Button id="addtime"
                    size="small"
                    variant="contained"
                    startIcon={<RemoveCircleIcon />}
                    onClick={deleteAllShowtimes}
                    sx={{ marginTop: "20px" }}>Delete All</Button>
                {/* <Button id="addtime" 
                size="small" 
                variant="contained" 
                startIcon={<AddBoxIcon />} 
                onClick={deleteMultiplex}
            >Delete Multiplex</Button> */}
            </div>

            {/* starts as an empty div */}
            {newShowTime}
            <div style={{ alignItems: 'center', display: 'flex', margin: 'auto', width: '80%', 'overflow': 'auto', color: 'white', border: '10px solid white', paddingLeft: 30, marginTop: 20 }}>
                {showtimes.map(
                    (movie) => <Paper elevation={5} sx={{marginRight: 5, marginBottom: 3, marginTop: 2, borderRadius: 5}}><MvShowtimes movie={movie} key={movie.movieId} /></Paper>
                )}
            </div>
            <br />
            <div className="align-right">
            </div>
            {/*<button onClick={() => addShowTime(mult.id)}>Add Showtime</button>*/}
            {/* newShowTime becomes NewShowComponent */}
        </Paper>
    </div>
}
export default Multiplex;