import { useEffect, useState } from "react"
import "./DiscountOffers.css"
import { Paper } from "@mui/material"
import apireqs from '../../APIReqs'

function DiscountsOffers(props) {
    const [discounts, setDiscounts] = useState([])
    const [offers, setOffers] = useState([])

    useEffect(() => {
        apireqs.getDiscounts().then(
            (res) => setDiscounts(res.data)
        ).catch(
            (res) => console.log("Get discounts failed", res)
        )
        apireqs.getOffers().then(
            (res) => setOffers(res.data)
        ).catch(
            (res) => console.log("Get offers failed", res)
        )
    }, [])
    return <div id="back">
        <div id='test'>
            <div id="discMain">
                {discounts.map((d) =>
                    <Paper id="disc" elevation={5} sx={{ m: 1, minHeight: 105, maxWidth: 200 }} key={d.discountId}>
                        <div id="disc" key={d.id}><h4>${d.amount} off</h4>{d.text} <p><b>Consumer:</b> Limit 1 coupon per purchase. Not to be combined with any other discounts.</p></div>
                    </Paper>)}
            </div>
            <div id="offMain">
                {offers.map((d) =>
                    <Paper id="off" elevation={5} sx={{ m: 1, minHeight: 110, maxWidth: 200 }} key={d.offerId}>
                        <div id="off" key={d.id}><h4>{d.amount}% off</h4>{d.text} <p><b>Consumer:</b> Limit 1 coupon per purchase. Not to be combined with any other offers.</p></div>
                    </Paper>)}
            </div>
        </div>
    </div>
}
export default DiscountsOffers