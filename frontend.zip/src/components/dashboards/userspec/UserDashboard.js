import Movies from ".././Movies"

import ResetPw from "../../authenticate/ResetPw"
import './UserDashboard.css'
import './DiscountOffers.css'
import { useEffect, useState } from "react"
import { FeedbackSend } from ".././Feedback"
import DiscountsOffers from "./DiscouuntsOffers"
import { Paper } from '@mui/material';
import apireqs from '../../APIReqs'

function UserDashboard(props) {
    const [email, setEmail] = useState('...')
    useEffect(
        () => {
            let key = localStorage.getItem('mLpXcs')
            if (key != '' && key != null) {
                apireqs.getUser(key).then((res) => {
                    console.log("logged in as", res.data)
                    setEmail(res.data.email)
                }).catch((res) => console.log("Get user failed", res))
            }

        }
        , [])
    return <div id="back">
        <Movies />
        <DiscountsOffers />
        <div id="min" style={{marginBottom: '60px'}}>
            <FeedbackSend type="user" />
            <ResetPw email={email} />
        </div>
    </div>
}
//<Paper elevation={3} sx={{ m: 1, minWidth: 600, minHeight: 400 }}>

export default UserDashboard