import { useEffect, useState } from "react"
import { useParams } from "react-router-dom"
import apireqs from '../APIReqs'
import LocationOnIcon from '@mui/icons-material/LocationOn';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import './ShowTime.css'
import '.././authenticate/Register.css'
import * as React from 'react';
import TextField from '@mui/material/TextField';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import Button from '@mui/material/Button';
import { Paper } from '@mui/material';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import ChairIcon from '@mui/icons-material/Chair';
import InfoIcon from '@mui/icons-material/Info';
import Box from '@mui/material/Box';
import Alert from '@mui/material/Alert';
import IconButton from '@mui/material/IconButton';
import Collapse from '@mui/material/Collapse';
import CloseIcon from '@mui/icons-material/Close';
import {AlertTitle} from "@mui/material";

function ShowTime(props) {
    const theme = createTheme({
        palette: {
            primary: {
                main: '#800000',
            }
        },
    });

    const gettimestr = datetime => {
        let datearr = datetime.split('T')[0].split('-')
        let date = parseInt(datearr[1])
            + "/" + parseInt(datearr[2])
            + "/" + (parseInt(datearr[0]) - 2000)
        let time = datetime.split('T')[1].split(':00.')[0]
        return date + " " + time
    }

    let params = useParams()
    let id = params.id

    const [confirmation, setConfirmation] = useState('');
    const [user, setUser] = useState('');
    const [open, setOpen] = React.useState();

    const [movie, setMovie] = useState({})
    const [showtime, setShowtime] = useState({})
    const [timestr, setTimestr] = useState('')
    const [multiplex, setMultiplex] = useState({})
    const [multiplexnotifs, setMultiplexNotifs] = useState([])
    const [offers, setOffers] = useState([])
    const [discounts, setDiscounts] = useState([])

    const [offerval, setofferval] = useState(0)
    const [discval, setdiscval] = useState(0)

    const [cost, setCost] = useState(0)


    useEffect(() => {
        apireqs.getDiscounts().then(
            (res) => {
                setDiscounts(res.data)
            }
        ).catch(
            (res) => console.log("Get discounts failed", res)
        )
        apireqs.getOffers().then(
            (res) => {
                setOffers(res.data)
            }
        ).catch(
            (res) => console.log("Get offers failed", res)
        )


        apireqs.getShowtime(id).then(
            (res) => {
                setTimestr(gettimestr(res.data.time))
                setShowtime(res.data)
                console.log(res.data)

                apireqs.getMovie(res.data.movieId).then(
                    (movieres) => {
                        setMovie(movieres.data)
                    }
                ).catch((movieerr) => {
                    setMovie({})
                })

                apireqs.getMultiplex(res.data.multiplexId).then(
                    (multres) => {
                        setMultiplex(multres.data)
                        setMultiplexNotifs(multres.data.notifs.split(';').map((ele) => <div>{ele}</div>))
                    }
                ).catch((multerr) => {
                    console.log("get multiplex failed", multerr)
                    setMultiplex({})
                })
            }
        ).catch((res) => console.log("get showtime " + id + " failed", res))

        calcCost()
    }, [])

    const calcCost = () => {
        let cost = (showtime.price * parseInt(document.getElementById("amt").value))
            * (100 - parseFloat(offerval)) / 100
            - parseFloat(discval)
        if (Number.isNaN(cost))
            cost = "0"
        setCost(cost)
    }
    useEffect(calcCost)

    const purchase = (e) => {
        
        e.preventDefault()

        if (parseInt(document.getElementById("amt").value) != parseFloat(document.getElementById("amt").value)) {
            document.getElementById('vco').innerHTML = "Number of tickets must be a whole number"
            setOpen(false)
            return
        }
        if (1 > parseInt(document.getElementById("amt").value)) {
            document.getElementById('vco').innerHTML = "Number of tickets must be at least 1"
            setOpen(false)
            return
        }
        if (showtime.remainderTix < parseInt(document.getElementById("amt").value)) {
            document.getElementById('vco').innerHTML = "Not enough seats left, please purchase a smaller number of tickets"
            setOpen(false)
            return
        }
        setOpen(true)
        document.getElementById('vco').innerHTML = ""
        /*alert(
            "Ticket purchase successful\n" +
            "Confirmation#" + (Math.random() + 1).toString(36) + "<br></br>" +
            "User#" + localStorage.getItem("mLpXcs") + " paid $" + cost + ", " + document.getElementById("amt").value + " ticket(s) for showtime#" + showtime.showtimeId + "\n" +
            "This is your receipt, take a screenshot"
        )*/
        setConfirmation(("#" + Math.random() + 1).toString(36))
        setUser("#" + localStorage.getItem("mLpXcs") + " paid $" + cost + ", " + document.getElementById("amt").value + " ticket(s) for showtime #" + showtime.showtimeId)
        showtime.remainderTix = parseInt(showtime.remainderTix) - parseInt(document.getElementById("amt").value)
        apireqs.addShowtime(showtime)
    }

    return <div id="mainBox">
        <Box id="rep" sx={{ width: 600, height: 50}}>
            <Collapse in={open}>
            
                <Alert 
                    action={
                        <IconButton
                            aria-label="close"
                            color="inherit"
                            onClick={() => {
                                setOpen(false);
                                window.location.reload()
                            }}
                        >
                            <CloseIcon fontSize="inherit" />
                        </IconButton>
                    }
                    sx={{ mb: 2 }}
                >
                    <AlertTitle sx={{textAlign: 'left', fontWeight: 'bold', fontSize: 'large'}}>Ticket Purchase Successful</AlertTitle>
                    <p id="receiptMsg">
                        <b>Confirmation </b>{confirmation}<br></br>
                        <b>User </b>{user}<br></br>
                        <b>This is your receipt, take a screenshot!</b>
                        </p>
                </Alert>
            </Collapse>
        </Box>
        <div style={{ alignItems: 'center', display: 'flex', height: '650px' }}>
            <div className="box">
                <img src={movie.poster} style={{ height: '97%', paddingTop: "20px"}} />
            </div>
            <div className="box">
                <h2 style={{ color: 'white', textTransform: 'uppercase', paddingTop: "50%" }}>{movie.title}</h2>
                Released {movie.releaseDate}
                <br /><br />
                <span id="timeMain"><AccessTimeIcon style={{ verticalAlign: "middle" }} /> {timestr}</span>
                <br /><br />
                <span><LocationOnIcon />
                    {multiplex.name} @ {multiplex.address}</span>
                <br></br>
                <br></br>
                <span id="notifs">
                    <InfoIcon />
                    {multiplexnotifs.length==1?<div> No notifications for this location</div>:<div></div>}
                    <span style={{ paddingLeft: "5px" }}>{multiplexnotifs}</span>
                </span>

            </div>
            <div className="box" id="content">
                <ThemeProvider theme={theme}>
                    <Paper elevation={3} sx={{ m: 1, minWidth: 400, minHeight: 500 }} id="mainPayPaper">
                        <h1>Buy Tickets</h1>
                        <h4 id="chairMain">
                            <div id="tixSeats"> #{showtime.remainderTix} <ChairIcon id="chair" style={{ verticalAlign: "middle" }} /> left</div>
                            <div id="tixCosts"> ${showtime.price} Per Ticket </div>
                        </h4>
                        <div id="vco" style={{ color: 'red', fontSize: "12px" }}></div>
                        <br></br>
                        <form>
                            <TextField id="amt" label="Number" variant="outlined" sx={{ m: 1, minWidth: 225 }} size="small"
                                type="number"
                                min="1"
                                onChange={calcCost}
                            />        <br />

                            <FormControl sx={{ m: 1, minWidth: 225 }} size="small">
                                <InputLabel id="offer-label">Apply Offer</InputLabel>
                                <Select
                                    id="offer"
                                    autoWidth
                                    label="Apply Offer"
                                    onChange={(e) => { setofferval(e.target.value) }}
                                >
                                    <MenuItem value="0" key={-1}>None</MenuItem>
                                    {offers.map((ele) => <MenuItem key={ele.offerId} value={ele.amount}>{ele.text} - {ele.amount}%</MenuItem>)}
                                </Select>
                                <div id="vsq"></div>
                            </FormControl>
                            <br></br>
                            <FormControl sx={{ m: 1, minWidth: 225 }} size="small">
                                <InputLabel id="discount-label">Apply Discount</InputLabel>
                                <Select
                                    id="discount"
                                    autoWidth
                                    label="Apply Discount"
                                    onChange={(e) => { setdiscval(e.target.value) }}
                                >
                                    <MenuItem value="0" key={-1}>None</MenuItem>
                                    {discounts.map((ele) => <MenuItem key={ele.offerId} value={ele.amount}>{ele.text} - ${ele.amount}</MenuItem>)}
                                </Select>
                            </FormControl>
                            <br></br>
                            <div id="mainOrder">
                                <p id="tixOrder">Total: </p>
                                <p id="tixTotal">${cost} </p>
                            </div>
                            <br></br>
                            <Button id="reg" variant="contained" sx={{ m: 1, minWidth: 225 }}
                                onClick={(e) => purchase(e)}
                            >Check Out</Button>

                        </form>

                    </Paper>
                </ThemeProvider>

            </div>
        </div>
    </div>
}
//, $<span id="cost">{cost}</span>

export default ShowTime