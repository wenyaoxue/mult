
import LocationOnIcon from '@mui/icons-material/LocationOn';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import { useEffect, useState } from 'react';
import apireqs from '../APIReqs'

function ShowtimeLink(props) {
    const gettimestr = datetime => {
        if (datetime == null)
            return ""
        let datearr = datetime.split('T')[0].split('-')
        let date = parseInt(datearr[1])
                +"/"+parseInt(datearr[2])
                +"/"+(parseInt(datearr[0])-2000)
        let time = datetime.split('T')[1].split(':00.')[0]
        return date + " " + time
    }
    // const 
    const [mult, setMult] = useState('??...')
    const timestr = gettimestr(props.st.time)
    useEffect(()=>{
        apireqs.getMultiplex(props.st.multiplexId).then(
            (res)=>{
                setMult(res.data.name)
            }
        ).catch(
            (res)=>{
                setMult('??...'+res.message)
            }
        )
    })

    return <a 
    href={`/showtime/${props.st.showtimeId}`} style={{color:'black', fontWeight: 'bold', display: 'flex', justifyContent: 'center', alignItems: 'self-end'}}>
        <LocationOnIcon/><spand style={{textTransform: "uppercase"}}>{mult}</spand> <AccessTimeIcon/> {timestr}<br/>
    </a>
}
export default ShowtimeLink;