import { useEffect, useState } from "react"
import { Paper } from "@mui/material"
import "./ownerspec/AppOwnerDashboard.css"
import Button from '@mui/material/Button';
import apireqs from "../APIReqs"
import './ShowTime.css'
import '.././authenticate/Register.css'
import * as React from 'react';
import { createTheme, ThemeProvider } from '@mui/material/styles';

function FeedbackSend(props) {
    const theme = createTheme({
        palette: {
            primary: {
                main: '#800000',
            }
        },
    });
    const feedbackSend = (e) => {
        e.preventDefault()
        let type = props.type
        let message = document.getElementById('msg').value
        let resolved = false
        let feedback = { type, message, resolved }
        if (message == '') {
            document.getElementById("vfb").innerHTML = "Message cannot be empty"
            return
        }
        apireqs.addFeedback(feedback).then(
            (res) => {
                document.getElementById("vfb").innerHTML = "Feedback submitted"
                document.getElementById('msg').value = ''
            }
        ).catch((err) => {
            document.getElementById("vfb").innerHTML = "Submit feedback failed " + err.message
        })
    }
    return (
        <div id="feedMain">
            <ThemeProvider theme={theme}>
                <Paper id="feedPaper" elevation={3} sx={{ m: 1, minHeight: 250, minWidth: 500}}>
                    <form>
                        <h2 id="feedTitle" style={{backgroundColor: '#800000', color: 'white', marginTop: 0, paddingTop: 15, paddingBottom: 20, borderRadius:3}}>Product Feedback</h2>
                        <textarea id="msg" rows={6} cols={50} placeholder="Type feedback here..."></textarea>
                        <br></br>
                        <div id="vfb"></div>
                        <Button id="subFeed" size="small" variant="contained" onClick={(e) => { feedbackSend(e) }}> Submit Feedback</Button>
                    </form>
                    <br></br>
                </Paper>
            </ThemeProvider>
        </div>
    );
}
function FeedbackView(props) {
    const [userFeedback, setUserFeedback] = useState([])
    const [adminFeedback, setAdminFeedback] = useState([])
    const init = () => {

        apireqs.getUserFeedback().then(
            (res) => {
                setUserFeedback(res.data)
            }
        ).catch((err) => {
            console.log("get user feedback failed", err.message)
        })
        apireqs.getAdminFeedback().then(
            (res) => {
                setAdminFeedback(res.data)
            }
        ).catch((err) => {
            console.log("get admin feedback failed", err.message)
        })
    }
    useEffect(() => {
        init()
    }, [])
    const changeResolved = (e, feedbackId, type, message) => {
        let resolved = e.currentTarget.checked, fbid
        let feedback = { feedbackId, type, message, resolved }
        apireqs.putFeedback(feedback)
        window.location.href = "/"
    }
    return <div>
        <Paper elevation={5} style={{ alignItems: 'center', display: 'flex', justifyContent: 'center', margin: 'auto', minHeight: 200, minWidth: 200, maxWidth: 700, backgroundColor: 'black' }}>
            <Paper elevation={5} sx={{ m: 1, minHeight: 200, minWidth: 300, paddingBottom: '20px' , borderRadius: '5px'}}>
                <h3 style={{ backgroundColor: '#800000', marginTop: 0, padding: 15, borderRadius: '5px', color: 'white' }}>User Feedback</h3>
                <ul>
                    {userFeedback.map((f) => <li key={f.feedbackId}>
                        <div id="mainItem"><div id="msgItem">{f.message}</div>
                            <div id="botItem">
                                <input type="checkbox" checked={f.resolved == "true"}
                                    onChange={(e) => changeResolved(e, f.feedbackId, "user", f.message)} />
                            </div></div>
                    </li>)}
                </ul>
            </Paper>
            <Paper elevation={5} sx={{ m: 1, minHeight: 200, minWidth: 300, paddingBottom: '20px', borderRadius: '5px'}}>
                <h3 style={{ backgroundColor: '#800000', marginTop: 0, padding: 15, borderRadius: '5px', color: 'white' }}>Admin Feedback</h3>
                <ul>
                    {adminFeedback.map((f) => <li key={f.feedbackId}>
                        <div id="mainItem"><div id="msgItem">{f.message}</div>
                            <div id="botItem">
                                <input type="checkbox" checked={f.resolved == "true"}
                                    onChange={(e) => changeResolved(e, f.feedbackId, "admin", f.message)} />
                            </div></div>
                    </li>)}
                </ul>
            </Paper>
        </Paper>
    </div >
}
export { FeedbackSend, FeedbackView }