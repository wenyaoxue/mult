import { useEffect, useState } from "react"
import { Paper } from "@mui/material"
import './AppOwnerDashboard.css'
import DeleteIcon from '@mui/icons-material/Delete';
import { TextField } from "@mui/material"
import Button from '@mui/material/Button';
import apireqs from '../../APIReqs'
import { createTheme, ThemeProvider } from '@mui/material/styles';


function MultiplexNotifsSingle(props) {
    const theme = createTheme({
        palette: {
            primary: {
              main: '#800000',
            }
          },
      });

    const [notif, setNotif] = useState('')

    const addNotif = (e, mult) => {
        e.preventDefault()
        apireqs.addNotif(mult, notif)
        window.location.href = "/"
    }
    const remNotif = (e, msg, mult) => {
        e.preventDefault()
        let newnotifs = mult.notifs.split(';')
        newnotifs = newnotifs.filter((ele) => msg != (ele))
        mult['notifs'] = newnotifs.join(';')
        console.log(mult)
        apireqs.addMultiplex(mult)
        window.location.href = "/"
    }

    return (
        <ThemeProvider theme={theme}>
            <Paper
                elevation={20} sx={{ m: 1, minHeight: 230, maxWidth: 300, borderRadius: '5px', backgroundColor: 'white'}}>
                <div id="mainOwner" key={props.mult.multiplexId} style={{ width: '300px', height: '200px', margin: 'auto' }} >
                    <div id="loc" style={{backgroundColor: '#800000', borderRadius: 5, marginBottom: 10, color: 'white', paddingTop: 10}}>
                        {props.mult.name} <br></br> {props.mult.address}  <br></br>  owned by #{props.mult.adminId}</div>
                    {props.mult.notifs.length > 0 ?
                        <ul>
                            {props.mult.notifs.split(';').slice(1).map((msg) =>
                                <li>
                                    <div id="mainItem"><div id="msgItem">{msg}</div>
                                        <div id="botItem"><button onClick={(e) => remNotif(e, msg, props.mult)}>
                                            <DeleteIcon sx={{ fontSize: 20 }} /></button></div></div>
                                </li>)}
                        </ul>
                        : <div></div>}
                    <div id="new">
                        <TextField
                            id="newnotif"
                            onChange={(e) => { setNotif(e.target.value) }}
                            label="Notification" variant="standard" size="small"  sx={{ m: 1, maxWidth: 180 }} />
                        <Button id="addnotif" size="small" variant="contained"
                            onClick={(e) => addNotif(e, props.mult)} >Add</Button>
                    </div>
                </div>
            </Paper>
        </ThemeProvider>
    );
}
export default MultiplexNotifsSingle