import { useEffect, useState } from "react"
import './AppOwnerDashboard.css';
import apireqs from '../../APIReqs'
import MultiplexNotifsSingle from "./MultiplexNotifsSingle";
import { Paper } from "@mui/material";

function MultiplexNotifs(props) {
    const [multiplexes, setMultiplexes] = useState([])
    const init = () => {
        apireqs.getMultiplexes().then((res)=>{
            setMultiplexes(res.data)
        }).catch((res)=>{
            console.log("get multiplexes failed", res.message)
        })
    }

    useEffect(init, [])
    return <div id="ownerMultMain">
        
        <h1 id="ownerMultiplex">Multiplexes</h1>
        <Paper elevation={10} style={{ alignItems: 'center', display: 'flex', margin: 'auto', width: '92.5%', 'overflow': 'auto', minHeight: 350, minWidth: '80%', 
        backgroundColor: 'black', color: 'white', border: '4px solid white', paddingLeft: 20 ,  paddingRight: 20, borderTopLeftRadius: 5, borderTopRightRadius: 5}}>
                {multiplexes.map(
                    (mult) => <MultiplexNotifsSingle key={mult.multiplexId} mult={mult}/>
                )}
            </Paper>
    </div>

}

export default MultiplexNotifs
//<input id="newnotif"/>
//<button onClick={(e)=>addNotif(e)}>add new notification for this location</button>
/*
    <div id="multBox">
            {multiplexes.map(
                (mult) => <MultiplexNotifsSingle key={mult.multiplexId} mult={mult}/>
            )}
        </div>
*/