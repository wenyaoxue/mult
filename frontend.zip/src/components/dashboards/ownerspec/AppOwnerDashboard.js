
import ResetPw from "../../authenticate/ResetPw"
import MultiplexNotifs from "./MultiplexNotifs"
import { FeedbackView } from ".././Feedback"

function AppOwnerDashboard(props) {
    return <div>
        
        <MultiplexNotifs />
        <br></br>
        <div style={{ marginBottom: '60px' }}>
            <FeedbackView />
            <ResetPw />
        </div>
    </div>
}

export default AppOwnerDashboard