import { useEffect, useState } from "react"
import AddMultiplex from "./adminspec/AddMultiplex"
import './adminspec/AdminDashboard.css'
import Button from '@mui/material/Button';
import AddBoxIcon from '@mui/icons-material/AddBox';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import apireqs from '../APIReqs'
import Multiplex from "./Multiplex"


function Multiplexes(props) {
    const [myMultiplexes, setMyMultiplexes] = useState([])
    const init = () => {
        apireqs.getOwnedMultiplexes(localStorage.getItem('mLpXcs')).then(
            (res)=>setMyMultiplexes(res.data)
        ).catch(
            (err)=>console.log("get my multiplexes failed", err)
        )
    }
    const [newMultiplex, setNewMultiplex] = useState(<div></div>)
    const addMultiplex = () => {
        setNewMultiplex(<AddMultiplex setThis={setNewMultiplex} refresh={init} />)
    }
    const theme = createTheme({
        palette: {
            primary: {
              main: '#800000',
            }
          },
      });
    useEffect(init, [])
    return <div>
        <ThemeProvider theme={theme}>
        <h1 id="pageName">Multiplexes</h1>
        <Button id="addtime" size="small" variant="contained" startIcon={<AddBoxIcon />} onClick={addMultiplex}>Multiplex</Button>
        
        {newMultiplex}
      
        {myMultiplexes.map(
            (mult) => <Multiplex mult={mult} init={init}/>
        )}


        </ThemeProvider>
    </div>

}

export default Multiplexes