import { useEffect, useState } from "react"
import MvShowtimes from "./MvShowtimes"
import Alert from '@mui/material/Alert';
import { Paper } from "@mui/material";
import apireqs from '.././APIReqs'
import LocationOnIcon from '@mui/icons-material/LocationOn';

function Movies(props) {
    const [multiplexes, setMultiplexes] = useState([])
    const [movies, setMovies] = useState([])

    const setAll = () => {
        setMovies([]) //but this takes time...not good
        console.log(movies)

        if (document.getElementById("multiplex").value === "All") {

            apireqs.getShowtimes().then(
                (res) => {
                    console.log("allshowtimes, grouped by movieid", res.data)
                    setMovies(
                        Object.entries(res.data).map((pair) => {
                            return { 'movieId': pair[0], 'showtimes': pair[1] }
                        })
                    )
                }
            ).catch(
                (res) => console.log("Get showtimes failed", res)
            )

            document.getElementById("multaddr").innerHTML = "No specifc multiplex selected"
            document.getElementById("multnotif").innerHTML = "Note: specific multiplexes might have policies to follow"
        }
        else {
            let multid = document.getElementById('multiplex').value
            apireqs.getShowtimesGroupedAt(multid).then(
                (res) => {
                    console.log("allshowtimes, grouped by movieid", res.data)
                    setMovies(
                        Object.entries(res.data).map((pair) => {
                            return { 'movieId': pair[0], 'showtimes': pair[1] }
                        })
                    )
                }
            ).catch(
                (res) => console.log("Get showtimes failed", res)
            )
            apireqs.getMultiplex(multid).then(
                (res) => {
                    console.log(res.data)
                    document.getElementById("multaddr").innerHTML = res.data.address
                    document.getElementById("multnotif").innerHTML = ""
                    let notarr = res.data.notifs.split(';').slice(1)
                    for (let i = 0; i < notarr.length; i++)
                        document.getElementById("multnotif").innerHTML += notarr[i] + "<br/>"
                    // document.getElementById("multnotif").innerHTML += res.data.notifs
                    if (res.data.notifs.length == 0)
                        document.getElementById("multnotif").innerHTML = "No notifications for this multiplex"
                }
            )
        }
    }

    const init = () => {
        setAll()
        apireqs.getMultiplexes().then(
            (res) => {
                setMultiplexes(res.data)
            }
        ).catch((err) => console.log("couldn't get multiplexes"))
    }
    useEffect(init, [])

    return <div>
        <div id="multiBox">
            <Paper id="multiPaper" elevation={5} sx={{ maxWidth: 900, minHeight: 100 }}>
                <h4>See movies at multiplex
                    <select id="multiplex" onChange={setAll}>
                        <option>All</option>
                        {multiplexes.map((ele) => <option value={ele.multiplexId} key={ele.multiplexId}>{ele.name}</option>)}
                    </select>
                    <LocationOnIcon style={{ height: '12px' }} />
                    <span style={{ color: 'white' }} id="multaddr">N/A</span>
                </h4>

                <Alert severity="info" variant="none" id="note">
                    <span id="multnotif"></span></Alert>
                {movies.length == 0 ? <div>No showtimes at this multiplex right now</div> : <div></div>}

            </Paper>
        </div>
        <div style={{display: 'flex', alignItems: 'center',justifyContent: 'center', marginRight: 100, marginLeft: 100, paddingBottom: 20, paddingTop: 10, borderRadius: 20}}>
            <div style={{ alignItems: 'center', display: 'flex', margin: 'auto', width: '80%', 'overflow': 'auto',  border: '6px solid white', paddingLeft: 30}}>
                {movies.map(
                    (movie) => <Paper elevation={5} sx={{ marginRight: 5, marginBottom: 3, marginTop: 2, borderRadius: 5 }}><MvShowtimes movie={movie} key={movie.movieId} /></Paper>
                )}
            </div>
        </div>
    </div>
}

export default Movies