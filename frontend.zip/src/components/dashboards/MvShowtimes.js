import './userspec/UserDashboard.css'
import { Paper } from '@mui/material'
import { useEffect, useState } from 'react';
import apireqs from '../APIReqs'
import ShowtimeLink from './ShowtimeLink';
function MvShowtimes(props) {
    const [movietitle, setmovietitle] = useState('Movie title not found...')
    const [movieposter, setmovieposter] = useState('Movie poster not found...')
    useEffect(()=>{
        apireqs.getMovie(props.movie.movieId).then(
            (res)=>{
                setmovietitle(res.data.title)
                setmovieposter(res.data.poster)
            }
        ).catch((res)=>{console.log(res.message)})
    },[])

    return (
        <div className="mainBox">
            <img src={movieposter} width="200" style={{borderRadius: 15}}/>
            <Paper id="movies" elevation={0} sx={{ m: 1, height: 110, width: 300, overflow:"auto", borderRadius: "20px", borderStyle: 'none'}}>
                <div id="title" style={{width:'90%',margin:'auto', textAlign:'center', paddingBottom: 10}}>
                    {movietitle}</div>
                {props.movie.showtimes.map(
                (st) => <ShowtimeLink st={st} key={st.showtimeId}/>)}
            </Paper>
        </div>
    );
}
export default MvShowtimes