import { useEffect, useState } from "react"
import apireqs from '../../APIReqs'
import * as React from 'react';
import TextField from '@mui/material/TextField';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import Button from '@mui/material/Button';
import { Paper } from '@mui/material';
import '../.././authenticate/Register.css'
import { createTheme, ThemeProvider } from '@mui/material/styles';

function AddShowTime(props) {
    const [movieId, setMovieId] = useState(-1)
    const add = (e) => {
        let submit = true;
        e.preventDefault()
        if (movieId == -1) {
            document.getElementById("vmv").innerHTML = "must not be empty"
            submit = false;
        } else {
            document.getElementById("vmv").innerHTML = ""
        }

        let multiplexId = parseInt(props.multId)

        let time = document.getElementById("time").value + ":00.000"
        if (time == ':00.000') {
            document.getElementById("vtm").innerHTML = "must not be empty"
            submit = false;
        } else {
            document.getElementById("vtm").innerHTML = ""
        }

        let tix = document.getElementById("tix").value
        if (parseInt(tix) != parseFloat(tix)) {
            document.getElementById("vtix").innerHTML = "must be a whole number"
            submit = false;
        } else if (parseInt(tix) < 0) {
            document.getElementById("vtix").innerHTML = "must not be negative"
            submit = false;
        } else {
            document.getElementById("vtix").innerHTML = ""
        }
        let remainderTix = tix

        let price = document.getElementById("prc").value
        if (price == '') {
            document.getElementById("vprc").innerHTML = "must not be empty"
            submit = false;
        } else if (parseInt(price) < 0) {
            document.getElementById("vprc").innerHTML = "must not be negative"
            submit = false;
        } else {
            document.getElementById("vprc").innerHTML = ""
        }

        if (!submit) {
            return
        }

        let st = { movieId, multiplexId, time, remainderTix, price }
        // console.log(st)
        apireqs.addShowtime(st).then((res) => {
            window.location.href = "/"
        })
    }
    const [multiplex, setMultiplex] = useState({})
    const [movies, setMovies] = useState([])
    useEffect(() => {
        setMultiplex({ 'id': props.multId, 'name': 'amc' })
        apireqs.getMovies().then((res) => {
            setMovies(res.data)
        }).catch((err) =>
            console.log("get movies failed", err)
        )
    }, [])
    const theme = createTheme({
        palette: {
            primary: {
                main: '#800000',
            }
        },
    });
    return <div >

        <ThemeProvider theme={theme}>
            <Paper elevation={3} sx={{ m: 1, minWidth: 600, maxWidth: 1100, marginLeft: '13%', marginRight: '13%', paddingTop: '2%', paddingBottom: '1%'}} id="mainPaper">
                <form>
                    <div style={{ display: 'inline-block' }}>
                        <div style={{ color: 'red' }} id="vmv"></div>
                        <FormControl sx={{ m: 1, minWidth: 225 }} size="small">
                            <InputLabel id="movie">Movie</InputLabel>
                            <Select
                                labelId="sq"
                                id="movie"
                                label="movie"
                                autoWidth
                                onChange={(e) => { setMovieId(e.target.value) }}
                            >
                                {movies.map((movie) =>
                                    <MenuItem value={movie.movieId} key={movie.movieId}>{movie.title}</MenuItem>
                                )}
                            </Select>
                        </FormControl>

                    </div>

                    <div style={{ display: 'inline-block' }}>
                        <div style={{ color: 'red' }} id="vtm"></div>
                        <TextField id="time" label="Start Time" InputLabelProps={{ shrink: true }} type="datetime-local" variant="outlined" sx={{ m: 1, minWidth: 225 }} size="small" />

                    </div>
                    <div style={{ display: 'inline-block' }}>
                        <div style={{ color: 'red' }} id="vtix"></div>
                        <TextField id="tix" label="Total Tickets" type="number" variant="outlined" sx={{ m: 1, minWidth: 225 }} size="small" />

                    </div>
                    <div style={{ display: 'inline-block' }}>
                        <div style={{ color: 'red' }} id="vprc"></div>
                        <TextField id="prc" label="Ticket Price" type="number" variant="outlined" sx={{ m: 1, minWidth: 225 }} size="small" />

                    </div>
                    <div style={{ display: 'inline-block' }}>
                        <Button id="reg" variant="contained" sx={{ m: 1, minWidth: 225 }}
                            onClick={(e) => add(e)}
                        >Add ShowTime</Button>
                        <Button id="reg" variant="contained" sx={{ m: 1, minWidth: 225, backgroundColor: 'grey' }}
                            onClick={(e) => props.setThis(<div></div>)}
                        >Cancel</Button>
                        <div></div>
                    </div>






                </form>
            </Paper>
        </ThemeProvider>
    </div>

}

export default AddShowTime