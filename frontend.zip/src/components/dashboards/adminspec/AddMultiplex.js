import { useEffect, useState } from "react"
import apireqs from '../../APIReqs'
import * as React from 'react';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import { Paper } from '@mui/material';
import '../.././authenticate/Register.css'
import { createTheme, ThemeProvider } from '@mui/material/styles';

function AddMultiplex(props) {
    const add = (e) => {
        let name = document.getElementById("name").value
        let adminId = localStorage.getItem('mLpXcs')
        let notifs = ""
        let address = document.getElementById("addr").value

        let mp = { name, adminId, notifs, address }

        if (name == "" || address == "") {
            document.getElementById("vam").innerHTML="Fields cannot be left blank"
            return
        }

        apireqs.addMultiplex(mp)
            .then((res)=>{
                document.getElementById("vam").innerHTML="Multiplex added successfully!"
                window.location.href = "/"
            })
            .catch((res)=>document.getElementById("vam").innerHTML=res.message)
    }
    const theme = createTheme({
        palette: {
            primary: {
                main: '#800000',
            }
        },
    });
    return <div id="addMult">
        <ThemeProvider theme={theme}>
            <Paper elevation={3} sx={{ m: 1, minWidth: 600, maxWidth: 1100 }} id="mainPaper">
                <form id="addForm">
                    <div id="vam" style={{color: 'red'}}></div>
                    <TextField id="name" label="Multiplex Name" variant="outlined" sx={{ m: 1, minWidth: 225 }} size="small" />
                    <TextField id="addr" label="Multiplex Address" sx={{ m: 1, minWidth: 225 }} size="small" />

                    <Button id="reg" variant="contained" sx={{ m: 1, minWidth: 225 }}
                        // onClick={(e) => register(e)}

                        onClick={(e) => add(e)}
                    >Add Multiplex</Button>
                    <Button id="reg" variant="contained" sx={{ m: 1, minWidth: 225, backgroundColor:'grey' }}
                            onClick={(e) => props.setThis(<div></div>)}
                        >Cancel</Button>
                </form>
            </Paper>
        </ThemeProvider>
    </div>

}

export default AddMultiplex