import { useState } from "react"
import ResetPw from "../../authenticate/ResetPw"
import { FeedbackSend } from "../Feedback"
import Multiplexes from "../Multiplexes"
import './AdminDashboard.css'

function AdminDashboard(props) {
    const admin = useState({})
    return (
        <div>
            <Multiplexes admin={admin} />
            <div id="min" style={{marginBottom: '60px'}}>
                <FeedbackSend type="admin" />
                <ResetPw />
            </div>
        </div>
    );
}

export default AdminDashboard