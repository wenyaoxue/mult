import { useEffect, useState } from "react"
import * as React from 'react';
import './Footer.css'
import { FeedbackSend } from "./dashboards/Feedback";
import ResetPw from "./authenticate/ResetPw";
import apireqs from "./APIReqs";
function Footer(props){
    const [email, setEmail] = useState('...')
    useEffect(
            ()=>{
                let key = localStorage.getItem('mLpXcs')
                if (key != '' && key != null) {
                    apireqs.getUser(key).then((res)=> {
                        console.log("logged in as", res.data)
                        setEmail(res.data.email)
                    }).catch((res)=>console.log("Get user failed", res))
                }

            }
    ,[])
    return (
        <div id="mainFooter" style={{position:"fixed", bottom: 0, left: 0}}>
            <br></br>
            <p style={{fontSize: 'small'}}>&copy; Creators: Crystal Wen, Andrew Velasquez, Ana Monter Diaz</p>
            <br></br>
            <br></br>
        </div>
    );
}

export default Footer