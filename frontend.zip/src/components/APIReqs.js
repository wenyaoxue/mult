import httpClient from "./config/BaseUrl";

///////////////////////////////////////////////////////////////////// USERS
const getAllUsers = () =>{
    console.log("GET users/allusers")
    return httpClient.get('/users/allusers');
}
const registerUser = user =>{
    console.log("POST users/createuser", user)
    return httpClient.post('/users/createuser', user)
}
const getUser = id => {
    console.log("GET users/getuser", id)
    return httpClient.get('users/getuser/'+id)
}
const loginUser = user => {
    console.log("POST users/login", user)
    return httpClient.post('users/login', user)
}
const getByEmail = email => {
    console.log("GET users/getuserbyemail/", email)
    return httpClient.get('users/getuserbyemail/'+email)
}
const resetPw = user => {
    console.log("POST users/reset", user)
    return httpClient.post('users/reset', user)
}

///////////////////////////////////////////////////////////////////// DISCOUNTS
const getDiscounts = () => {
    console.log("GET discounts/getdiscounts")
    return httpClient.get('discounts/getdiscounts')
}

///////////////////////////////////////////////////////////////////// OFFERS
const getOffers = () => {
    console.log("GET offers/getoffers")
    return httpClient.get('offers/getoffers')
}

///////////////////////////////////////////////////////////////////// MOVIES
const getMovie = id => {
    console.log("GET movies/getmovie/",id)
    return httpClient.get('movies/getmovie/'+id)
}
const getMovies = () => {
    console.log("GET movies/allmovies")
    return httpClient.get('movies/allmovies')
}

///////////////////////////////////////////////////////////////////// SHOWTIME
const getShowtimes = () => {
    console.log("GET showtime/getshowtimesgrouped")
    return httpClient.get('showtime/getshowtimesgrouped')
}
const getShowtimesGroupedAt = id => {
    console.log("GET showtime/getshowtimesgroupedat/"+id)
    return httpClient.get('showtime/getshowtimesgroupedat/'+id)
}
const getShowtime = id => {
    console.log('GET showtime/getshowtime/'+id)
    return httpClient.get('showtime/getshowtime/'+id)
}
const addShowtime = st => {
    console.log('POST showtime/addshowtime',st)
    return httpClient.post('showtime/addshowtime', st)
}
const delShowtime = id => {
    console.log('DELETE showtime/deleteshowtime/'+id)
    return httpClient.delete('showtime/deleteshowtime/'+id)
}

///////////////////////////////////////////////////////////////////// MULTIPLEX
const getMultiplex = id => {
    console.log('GET multiplex/getmultiplex/'+id)
    return httpClient.get('multiplex/getmultiplex/'+id)
}
const addMultiplex = mp => {
    console.log('POST multiplex/addmultiplex', mp)
    return httpClient.post('multiplex/addmultiplex', mp)
}
const getMultiplexes = () => {
    console.log('GET multiplex/getmultiplex')
    return httpClient.get('multiplex/getmultiplex')
}
const getOwnedMultiplexes = adminId => {
    console.log('GET multiplex/getmultiplexownedby/'+adminId)
    return httpClient.get('multiplex/getmultiplexownedby/'+adminId)
}
const addNotif = (mp, n) => {
    console.log('POST multiplex/addnotif/'+n, mp)
    return httpClient.post('multiplex/addnotif/'+n, mp)
}
const delMultiplex = id => {
    console.log('DELETE multiplex/deletemultiplex/'+id)
    return httpClient.delete('multiplex/deletemultiplex/'+id)
}

///////////////////////////////////////////////////////////////////// FEEDBACK
const getUserFeedback = () => {
    console.log('GET feedback/getuserfeedback')
    return httpClient.get('feedback/getuserfeedback')
}
const getAdminFeedback = () => {
    console.log('GET feedback/getadminfeedback')
    return httpClient.get('feedback/getadminfeedback')
}
const addFeedback = fb => {
    console.log('POST feedback/addfeedback', fb)
    return httpClient.post('feedback/addfeedback', fb)
}
const putFeedback = fb => {
    console.log('PUT feedback/updatefeedback', fb)
    return httpClient.put('feedback/updatefeedback', fb)
}

export default { getAllUsers, registerUser, loginUser, getUser, getByEmail, resetPw ,
    getDiscounts, getOffers,
    getMovie, getMovies,
    getShowtimes, getShowtime, getShowtimesGroupedAt, addShowtime, delShowtime,
    getMultiplex, getMultiplexes, getOwnedMultiplexes, addMultiplex, addNotif, delMultiplex,
    getUserFeedback, getAdminFeedback, addFeedback, putFeedback
}; //method1, method2, ...