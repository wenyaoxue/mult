import { useEffect, useState } from "react"
import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import './Header.css'
import MovieFilterIcon from '@mui/icons-material/MovieFilter';
import apireqs from "./APIReqs";
import { createTheme, ThemeProvider } from '@mui/material/styles';
function Header(props) {


    const [user, setUser] = useState({})
    useEffect(() => {
        let key = localStorage.getItem('mLpXcs')
        if (key != '' && key != null) {
            setUser({ 'username': '...' }) //get from usertable using localstorage id
            
            apireqs.getUser(key).then((res)=> {
                console.log("logged in as", res.data)
                setUser(res.data)
            }).catch((res)=>console.log("Get user failed", res))
        }
        else
            setUser({})
    }, [])

    const logout = (e) => {
        localStorage.setItem('mLpXcs', '')
        setUser({})
        window.location.href="/"
    }

    const theme = createTheme({
        palette: {
            primary: {
              main: '#800000',
            },
            secondary: {
              main: '#E0C2FF',
              light: '#F5EBFF',
              contrastText: '#47008F',
            },
            //mode: 'dark'
          },
      });

    return (
        <ThemeProvider theme={theme}>
        <Box sx={{ flexGrow: 1 }} >
            <AppBar position= "fixed" color="primary">
                <Toolbar>
                    <IconButton
                        size="large"
                        edge="start"
                        color="inherit"
                        aria-label="menu"
                        sx={{ mr: 2 }}
                    >
                        <a href="/"><MovieFilterIcon/></a>
                    </IconButton>
                    
                    {user.userId==null?<div id="links">
                        <Button color="inherit"><a href="/login">Login</a></Button>
                        <Button color="inherit"><a href="/register">Register</a></Button>
                    </div>:
                    <div id="links">
                        <Button color="inherit" style={{fontWeight: 'bold', fontSize: 'medium'}} onClick={logout}>Log Out</Button>
                        <Button color="inherit" style={{fontWeight: 'bold', fontSize: 'medium'}}><a href="/">{user.username}</a></Button>
                        
                    </div>}

                </Toolbar>
            </AppBar>
            <Toolbar></Toolbar>
        </Box>
        </ThemeProvider>
    );
}

export default Header