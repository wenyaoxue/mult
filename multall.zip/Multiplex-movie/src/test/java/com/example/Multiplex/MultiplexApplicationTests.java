package com.example.Multiplex;
import static org.junit.Assert.assertEquals;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.controller.MovieController;
import com.entity.Movie;
import com.service.MovieService;

@SpringBootTest
class MultiplexApplicationTests {

	@Autowired 
	MovieService movieService;
	@Autowired
	MovieController movieController;
	public static Movie m1;
	public static Movie m2;
	
	@BeforeAll
	public static void setUp() {
		m1 = new Movie(101, "https://image.tmdb.org/t/p/w500/5O1GLla5vNuegqNxNhKL1OKE1lO.jpg", "2022-09-15", "Sample movie1");
		m2 = new Movie(102, "https://image.tmdb.org/t/p/w500/5O1GLla5vNuegqNxNhKL1OKE1lO.jpg", "2022-09-15", "Sample movie2");
	}
	
	@Test
	void testAddMovie() {
		int dataSize = movieController.getAllMovies().size();
		movieController.addMovie(m1);
		int movieId = 0;
		for(Movie m : movieController.getAllMovies()) {
			if(m.getTitle().equals("Sample movie1")) {
				movieId = m.getMovieId();
			}
		}
		assertEquals(movieController.getAllMovies().size(), dataSize + 1);
		movieController.deleteMovie(movieId);
	}
	@Test
	void testUpdateMovie() {
		movieController.addMovie(m1);
		int movieId = 0;
		for(Movie m : movieController.getAllMovies()) {
			if(m.getTitle().equals("Sample movie1")) {
				movieId = m.getMovieId();
			}
		}
		movieController.updateMovie(new Movie(movieId, m1.getPoster(), m1.getReleaseDate(), "updated movie1 title"));
		String title = "";
		for(Movie m : movieController.getAllMovies()) {
			if(m.getMovieId() == movieId) {
				title = m.getTitle();
			}
		}
		assertEquals(title, "updated movie1 title");
		movieController.deleteMovie(movieId);
	}
}
