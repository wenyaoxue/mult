package com.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Table(name = "movie")
@Data
//@NoArgsConstructor
//@AllArgsConstructor
@ToString
public class Movie {
	@Id
	@GeneratedValue
	private int movieId;
	private String poster;
	private String releaseDate;
	private String title;
	public int getMovieId() {
		return movieId;
	}
	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}
	public String getPoster() {
		return poster;
	}
	public void setPoster(String poster) {
		this.poster = poster;
	}
	public String getReleaseDate() {
		return releaseDate;
	}
	public void setReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Movie(int movieId, String poster, String releaseDate, String title) {
		super();
		this.movieId = movieId;
		this.poster = poster;
		this.releaseDate = releaseDate;
		this.title = title;
	}
	public Movie() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	
	
}
