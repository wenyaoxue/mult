package com.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.Feedback;
import com.repository.FeedbackRepository;

@Service
public class FeedbackService {
	@Autowired
	private FeedbackRepository repo;

	public List<Feedback> getUserFeedback() {
		ArrayList<Feedback> uFeedback =  repo.findAll().stream()
				.filter(f -> f.getType().equals("user"))
				.collect(Collectors.toCollection(ArrayList::new));
		
		Collections.sort(uFeedback, new Comparator<Feedback>() {

			@Override
			public int compare(Feedback o1, Feedback o2) {
				return o1.getResolved().compareTo(o2.getResolved());
			}
			
		});
		return uFeedback;
	}

	public List<Feedback> getAdminFeedback() {
		ArrayList<Feedback> aFeedback =  repo.findAll().stream()
				.filter(f -> f.getType().equals("admin"))
				.collect(Collectors.toCollection(ArrayList::new));
		
		Collections.sort(aFeedback, new Comparator<Feedback>() {

			@Override
			public int compare(Feedback o1, Feedback o2) {
				return o1.getResolved().compareTo(o2.getResolved());
			}
			
		});
		return aFeedback;
	}

	public String deleteFeedback(int id) {
		if(!repo.findById(id).isPresent()) {
			return "Feedback not found with this id";
		}
		else {
			repo.deleteById(id);
			return "Feedback deleted";
		}
	}

	
	
	

	
}
