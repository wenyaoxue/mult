package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.entity.Feedback;
import com.repository.FeedbackRepository;
import com.service.FeedbackService;

@RestController
@RequestMapping("/api/feedback")
//@CrossOrigin("*")
@RefreshScope
public class FeedbackController {
	@Autowired
	private FeedbackRepository repo;
	@Autowired
	private FeedbackService service;

		
		@GetMapping("/getuserfeedback")
		public List<Feedback> getUserFeedback() {
			return service.getUserFeedback();
		}
		@GetMapping("/getadminfeedback")
		public List<Feedback> getAdminFeedback() {
			return service.getAdminFeedback();
		}
		@PostMapping("/addfeedback")
		public Feedback addFeedback(@RequestBody Feedback feedback) {
			return repo.save(feedback);
		}
		@DeleteMapping("/deleteall")
		public void deleteall() {
			repo.deleteAll();
		}
		@DeleteMapping("/deletefeedback/{id}")
		public String deleteFeedback(@PathVariable int id) {
			return service.deleteFeedback(id);
		}
		@PutMapping("/updatefeedback")
		public Feedback updateFeedback(@RequestBody Feedback feedback) {
			return repo.save(feedback);
		}
}
