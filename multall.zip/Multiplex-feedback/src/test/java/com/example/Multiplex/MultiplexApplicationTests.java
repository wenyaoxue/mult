package com.example.Multiplex;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.controller.FeedbackController;
import com.entity.Feedback;
import com.service.FeedbackService;



@SpringBootTest
class MultiplexApplicationTests {

	@Autowired
	FeedbackService service;
	@Autowired 
	FeedbackController controller;
	public static Feedback f1;
	
	@BeforeAll
	public static void setUp() {
		f1 = new Feedback(900, "user", "sampleFeedback", "false");
	}
	@Test
	void testAdd() {
		int dataSize = controller.getUserFeedback().size();
		controller.addFeedback(f1);
		assertEquals(controller.getUserFeedback().size(), dataSize + 1);
		int feedId = 0;
		for(Feedback f : controller.getUserFeedback()) {
			if(f.getMessage().equals("sampleFeedback")) {
				feedId = f.getFeedbackId();
			}
		}
		controller.deleteFeedback(feedId);
	}
	@Test
	void testUpdate() {
		controller.addFeedback(f1);
		int feedId = 0;
		for(Feedback f : controller.getUserFeedback()) {
			if(f.getMessage().equals("sampleFeedback")) {
				feedId = f.getFeedbackId();
			}
		}
		controller.updateFeedback(new Feedback(feedId, f1.getType(), "sampleFeedback1", f1.getResolved()));
		controller.deleteFeedback(feedId);
	}
}
