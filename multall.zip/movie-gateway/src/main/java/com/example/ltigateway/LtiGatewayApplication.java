package com.example.ltigateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.CrossOrigin;

@SpringBootApplication
public class LtiGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(LtiGatewayApplication.class, args);
	}
	@Bean
	RouteLocator userRoute(RouteLocatorBuilder builder) {
		return builder.routes()
				
			.route("ps",rs ->rs
					.path("/api/users/**").uri("lb://movie-user"))
			.build();
	}
	@Bean
	RouteLocator showtimeRoute(RouteLocatorBuilder builder) {
		return builder.routes()
				
			.route("sh",rs ->rs
					.path("/api/showtime/**").uri("lb://movie-showtime"))
			.build();
	}
	@Bean
	RouteLocator multiplexRoute(RouteLocatorBuilder builder) {
		return builder.routes()
				
			.route("mp",rs ->rs
					.path("/api/multiplex/**").uri("lb://movie-multiplex"))
			.build();
	}
	@Bean
	RouteLocator movieRoute(RouteLocatorBuilder builder) {
		return builder.routes()
				
			.route("m",rs ->rs
					.path("/api/movies/**").uri("lb://movie-movie"))
			.build();
	}
	@Bean
	RouteLocator discountRoute(RouteLocatorBuilder builder) {
		return builder.routes()
				
			.route("d",rs ->rs
					.path("/api/discounts/**").uri("lb://movie-discount"))
			.build();
	}
	@Bean
	RouteLocator feedbackRoute(RouteLocatorBuilder builder) {
		return builder.routes()
				
			.route("f",rs ->rs
					.path("/api/feedback/**").uri("lb://movie-feedback"))
			.build();
	}
	@Bean
	RouteLocator offerRoute(RouteLocatorBuilder builder) {
		return builder.routes()
				
			.route("o",rs ->rs
					.path("/api/**").uri("lb://movie-offer"))
			.build();
	}
	
}
