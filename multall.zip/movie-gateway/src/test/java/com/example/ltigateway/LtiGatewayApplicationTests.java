package com.example.ltigateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LtiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
