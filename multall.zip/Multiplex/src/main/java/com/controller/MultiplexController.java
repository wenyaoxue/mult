package com.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.model.Multiplex;
import com.repo.MultiplexRepo;
import com.service.MultiplexService;

@RestController
@RequestMapping("/api/multiplex")
//@CrossOrigin("*")
@RefreshScope
public class MultiplexController {
	@Autowired
	private MultiplexService service;
	
	@Autowired
	private MultiplexRepo repo;
	
	@GetMapping("/getmultiplex")
	public List<Multiplex> loadAll(){
		return service.loadAll();
	}
	@GetMapping("/getmultiplex/{id}")
	public Multiplex getMultiplex(@PathVariable int id) {
		return repo.findById(id).get();
	}
	@GetMapping("/getmultiplexownedby/{id}")
	public List<Multiplex> getmultiplexownedby(@PathVariable int id) {
		return service.getmultiplexownedby(id);
	}
	@PostMapping("/addmultiplex")
	public Multiplex addMultiplex(@RequestBody Multiplex multiplex) {
		return repo.save(multiplex);
	}
	@DeleteMapping("/deletemultiplex/{id}")
	public String deleteMultiplex(@PathVariable Integer id) {
		if(!repo.findById(id).isPresent()) {
			return "Multiplex not found";
		}
		else {
			repo.deleteById(id);
			return "Multiplex deleted";
		}
	}
	@PostMapping("/addnotif/{string}")
	public Multiplex addNotif(@RequestBody Multiplex multiplex, @PathVariable String string) {
		String append = ";" + string; 
		multiplex.setNotifs(multiplex.getNotifs().concat(append));
		return repo.save(multiplex);
	}
}
