package com.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.Multiplex;
import com.repo.MultiplexRepo;

@Service
public class MultiplexService {
	@Autowired
	private MultiplexRepo repo;

	public List<Multiplex> loadAll() {
		return repo.findAll();
	}
	
	public List<Multiplex> getmultiplexownedby(int id) {
		return repo.findAll().stream()
				.filter(f -> f.getAdminId() == id)
				.collect(Collectors.toCollection(ArrayList::new));
	}

	
	
	
}
