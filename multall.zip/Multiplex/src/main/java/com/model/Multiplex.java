package com.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Entity
@Data
//@AllArgsConstructor
//@NoArgsConstructor
@Table(name="multiplex")
public class Multiplex {
	@Id
	@GeneratedValue
	private int multiplexId;
	private String name;
	private int adminId;
	private String notifs;
	private String address;
	public int getMultiplexId() {
		return multiplexId;
	}
	public void setMultiplexId(int multiplexId) {
		this.multiplexId = multiplexId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAdminId() {
		return adminId;
	}
	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}
	public String getNotifs() {
		return notifs;
	}
	public void setNotifs(String notifs) {
		this.notifs = notifs;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Multiplex(int multiplexId, String name, int adminId, String notifs, String address) {
		super();
		this.multiplexId = multiplexId;
		this.name = name;
		this.adminId = adminId;
		this.notifs = notifs;
		this.address = address;
	}
	public Multiplex() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	
	
}
