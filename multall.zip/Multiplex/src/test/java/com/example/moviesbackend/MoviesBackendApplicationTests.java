package com.example.moviesbackend;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import static org.junit.Assert.assertEquals;
import com.controller.MultiplexController;
import com.model.Multiplex;

@SpringBootTest
class MoviesBackendApplicationTests {

	@Autowired
	MultiplexController controller;
	public static Multiplex m1;
	
	@BeforeAll
	public static void setUp() {
		m1 = new Multiplex(900, "myMulti", 1, "testNotif", "sampleAddress");
	}
	@Test
	void TestAdd() {
		int dataSize = controller.loadAll().size();
		controller.addMultiplex(m1);
		assertEquals(controller.loadAll().size(), dataSize + 1);
		int multiId = 0;
		for(Multiplex m : controller.loadAll()) {
			if(m.getAddress().equals("sampleAddress")) {
				multiId = m.getMultiplexId();
			}
		}
		controller.deleteMultiplex(multiId);
	}
	@Test
	void testaddNotif() {
		controller.addMultiplex(m1);
		int multiId = 0;
		for(Multiplex m : controller.loadAll()) {
			if(m.getAddress().equals("sampleAddress")) {
				multiId = m.getMultiplexId();
			}
		}
		controller.addNotif(new Multiplex(multiId, m1.getName(), m1.getAdminId(), m1.getNotifs(), m1.getAddress()), "123");
		assertEquals(controller.getMultiplex(multiId).getNotifs(), "testNotif;123");
		controller.deleteMultiplex(multiId);
	}
}
