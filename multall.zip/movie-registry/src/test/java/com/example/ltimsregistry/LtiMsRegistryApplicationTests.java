package com.example.ltimsregistry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LtiMsRegistryApplicationTests {

	@Test
	void contextLoads() {
	}

}
