package com.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.Discount;
import com.repository.DiscountRepository;

@Service
public class DiscountService {
	@Autowired
	private DiscountRepository repo;

	public String deleteDiscount(int id) {
		if(!repo.findById(id).isPresent()) {
			return "Discount not found";
		}
		else {
			repo.deleteById(id);
			return "Discount deleted";
		}
	}

	

	
	
	

	
}
