package com.example.Multiplex;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.controller.DiscountController;
import com.entity.Discount;
import com.service.DiscountService;

@SpringBootTest
class MultiplexApplicationTests {

	@Autowired
	DiscountService service;
	@Autowired 
	DiscountController controller;
	public static Discount d1;
	
	@BeforeAll
	public static void setUp() {
		d1 = new Discount(100, 100.00, "sample1");
	}
	@Test
	void testAdd() {
		int dataSize = controller.getDiscounts().size();
		controller.addDiscount(d1);
		assertEquals(controller.getDiscounts().size(), dataSize + 1);
		int discId = 0;
		for(Discount d : controller.getDiscounts()) {
			if(d.getText().equals("sample1")) {
				discId = d.getDiscountId();
			}
		}
		controller.deleteDiscount(discId);
	}
	@Test
	void testUpdate() {
		controller.addDiscount(d1);
		int discId = 0;
		for(Discount d : controller.getDiscounts()) {
			if(d.getText().equals("sample1")) {
				discId = d.getDiscountId();
			}
		}
		controller.updateDiscount(new Discount(discId, d1.getAmount(), "sample2"));
		controller.deleteDiscount(discId);
	}
}
