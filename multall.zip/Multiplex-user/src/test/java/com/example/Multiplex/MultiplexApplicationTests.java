package com.example.Multiplex;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.controller.UserController;
import com.entity.User;
import com.repository.UserRepository;
import com.service.UserService;

@SpringBootTest
class MultiplexApplicationTests {

	@Autowired
	UserService service;
	@Autowired 
	UserController controller;
	public static User u1;
	public static User u2;
	
	@BeforeAll
	public static void setUp() {
	u1 = new User((long)101, "andrew", "password", "me@me", "dog?", "Roxy", "true", "false", "false");
	u2 = new User((long)102, "bob", "password", "me@me", "dog?", "Roxy", "true", "false", "false");

	}
	@Test
	void testAdd() {
		int dataSize = controller.getAllUsers().size();
		controller.createUser(u1);
		assertEquals(service.getUsers().size(), dataSize + 1);
		long uId = 0;
		List<User> allUsers = controller.getAllUsers();
		for(User u : allUsers) {
			if(u.getUsername().equals("andrew")) {
				uId = u.getUserId();
			}
		}
		controller.deleteUser(uId);
	}
	@Test
	void testGetUserById() {
		controller.createUser(u1);
		List<User> allUsers = controller.getAllUsers();
		long uId = 0;
		for(User u : allUsers) {
			if(u.getUsername().equals("andrew")) {
				uId = u.getUserId();
			}
		}
		User foundUser = controller.getUser(uId);
		assertEquals(foundUser.getUserId() == uId, true);
		controller.deleteUser(uId);
	}
	@Test
	void updateUser() {
		controller.createUser(u1);
		long uId = 0;
		for(User u : controller.getAllUsers()) {
			if(u.getUsername().equals("andrew")) {
				uId = u.getUserId();
			}
		}
		User foundUser = controller.getUser(uId);
		User updatedU = controller.updateUser(new User(uId, "andrew", "passwords", "me@me", "dog?", "Roxy", "true", "false", "false"));
		assertEquals(controller.getUser(uId).getPassword(), "passwords");
		controller.deleteUser(uId);
	}
	@Test
	void testLogin() {
		controller.createUser(u1);
		List<User> allUsers = controller.getAllUsers();
		long uId = 0;
		for(User u : allUsers) {
			if(u.getUsername().equals("andrew")) {
				uId = u.getUserId();
			}
		}
		User loginUser = new User();
		loginUser.setUsername("andrew");
		loginUser.setPassword("password");
		assertEquals(controller.login(loginUser).getUserId() == uId, true);
		controller.deleteUser(uId);
	}
	
}
