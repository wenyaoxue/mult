package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.User;
import com.repository.UserRepository;

@Service
public class UserService {
	@Autowired
	private UserRepository repo;
	
	public List<User> getUsers(){
		return repo.findAll();
	}

	public User login(User user) {
		String username = user.getUsername();
		String password = user.getPassword();
		List<User>users = repo.findAll();
//		boolean found = false;
		for(User u: users) {
			if(u.getUsername().equals(username) && u.getPassword().equals(password)) {
//				found = true;
				return u;
			}
		}
		return null;
	}

	public User getByEmail(String email) {
		List<User>users = repo.findAll();
		for(User u : users) {
			if(u.getEmail().equals(email)) {
				return u;
			}
		}
		return null;
	}

	public User reset(User user) {
		String email = user.getEmail();
		String password = user.getPassword();
		List<User>users = repo.findAll();
		boolean found = false;
		for(User u : users) {
			if(u.getEmail().equals(email)) {
				u.setPassword(password);
				repo.save(u);
				return u;
			}
		}
		return null;
	}

	public String deleteUser(long id) {
		if(!repo.findById(id).isPresent()) {
			return "User not found with id:" + id;
		}
		else {
			repo.deleteById(id);
			return "User deleted";
		}
	}
}
