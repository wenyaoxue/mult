package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.entity.User;
import com.repository.UserRepository;
import com.service.UserService;

@RestController
@RequestMapping("/api/users")
//@CrossOrigin("*")
@RefreshScope
public class UserController {
	@Autowired
	private UserRepository repo;
	@Autowired
	private UserService service;

		
		@GetMapping("/allusers")
		public List<User> getAllUsers() {
			List<User> userList = repo.findAll();
			System.out.println(userList);
			return repo.findAll();
		}
		@GetMapping("/getuser/{id}")
		public User getUser(@PathVariable long id) {
				return repo.findById(id).get();
		}
		@GetMapping("/getuserbyemail/{email}")
		public User getUser(@PathVariable String email) {
				return service.getByEmail(email);
		}
		
		@PostMapping("/createuser")
		public User createUser(@RequestBody User user) {
			System.out.println(user);
			return repo.save(user);
		}
		@DeleteMapping("/deleteuser/{id}")
		public String deleteUser(@PathVariable long id) {
			return service.deleteUser(id);
		}
		@PutMapping("/updateuser")
		public User updateUser(@RequestBody User user) {
			return repo.save(user);
		}
		@PostMapping("/login")
		public User login(@RequestBody User user) {
			return service.login(user);
		}
		@PostMapping("/reset")
		public User reset(@RequestBody User user) {
			 return service.reset(user);
		}
}
