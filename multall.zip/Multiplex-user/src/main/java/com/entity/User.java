package com.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Table(name = "users")
@Data
//@NoArgsConstructor
//@AllArgsConstructor
@ToString
public class User {
	@Id
	@GeneratedValue
	private Long userId;
	private String username;
	private String password;
	private String email;
	private String securityQuestion;
	private String answer;
	private String isUser;
	private String isAdmin;
	private String isOwner;
	
	
	public Long getUserId() {
		return userId;
	}


	public void setUserId(Long userId) {
		this.userId = userId;
	}


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getSecurityQuestion() {
		return securityQuestion;
	}


	public void setSecurityQuestion(String securityQuestion) {
		this.securityQuestion = securityQuestion;
	}


	public String getAnswer() {
		return answer;
	}


	public void setAnswer(String answer) {
		this.answer = answer;
	}


	public String getIsUser() {
		return isUser;
	}


	public void setIsUser(String isUser) {
		this.isUser = isUser;
	}


	public String getIsAdmin() {
		return isAdmin;
	}


	public void setIsAdmin(String isAdmin) {
		this.isAdmin = isAdmin;
	}


	public String getIsOwner() {
		return isOwner;
	}


	public void setIsOwner(String isOwner) {
		this.isOwner = isOwner;
	}


	public User(Long userId, String username, String password, String email, String securityQuestion, String answer,
			String isUser, String isAdmin, String isOwner) {
		super();
		this.userId = userId;
		this.username = username;
		this.password = password;
		this.email = email;
		this.securityQuestion = securityQuestion;
		this.answer = answer;
		this.isUser = isUser;
		this.isAdmin = isAdmin;
		this.isOwner = isOwner;
	}


	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
