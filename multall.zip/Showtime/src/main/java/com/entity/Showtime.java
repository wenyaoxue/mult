package com.entity;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Table(name = "showtimes")
@Data
//@NoArgsConstructor
//@AllArgsConstructor
@ToString
@TypeDefs(@TypeDef(name="localDateTimeType",typeClass=org.hibernate.type.LocalDateTimeType.class))
public class Showtime {
	@Id
	@GeneratedValue
	private Integer showtimeId;
	private int movieId;
	private int multiplexId;
	@Type(type="localDateTimeType")
	@JsonFormat(pattern="yyy-MM-dd'T'HH:mm:ss.SSS")
	private LocalDateTime time;
	private int remainderTix;
	private float price;
	public Integer getShowtimeId() {
		return showtimeId;
	}
	public void setShowtimeId(Integer showtimeId) {
		this.showtimeId = showtimeId;
	}
	public Integer getMovieId() {
		return movieId;
	}
	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}
	public int getMultiplexId() {
		return multiplexId;
	}
	public void setMultiplexId(int multiplexId) {
		this.multiplexId = multiplexId;
	}
	public LocalDateTime getTime() {
		return time;
	}
	public void setTime(LocalDateTime time) {
		this.time = time;
	}
	public int getRemainderTix() {
		return remainderTix;
	}
	public void setRemainderTix(int remainderTix) {
		this.remainderTix = remainderTix;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public Showtime(Integer showtimeId, int movieId, int multiplexId, LocalDateTime time, int remainderTix, float price) {
		super();
		this.showtimeId = showtimeId;
		this.movieId = movieId;
		this.multiplexId = multiplexId;
		this.time = time;
		this.remainderTix = remainderTix;
		this.price = price;
	}
	public Showtime() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
