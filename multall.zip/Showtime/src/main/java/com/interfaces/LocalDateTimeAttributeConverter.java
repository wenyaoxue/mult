package com.interfaces;

public class LocalDateTimeAttributeConverter {

}
