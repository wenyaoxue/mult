package com.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.Showtime;
import com.repository.ShowtimeRepository;

@Service
public class ShowtimeService {
	@Autowired
	private ShowtimeRepository repo;

	public List<Showtime> getShowtimesByLocation(int id) {
		return repo.findAll().stream()
				.filter(f -> f.getMultiplexId() == id)
				.collect(Collectors.toCollection(ArrayList::new));
	}
	public List<Showtime> getMovie(int id) {
		return repo.findAll().stream()
				.filter(f -> f.getMovieId() == id)
				.collect(Collectors.toCollection(ArrayList::new));
		
	}

	public Map<Integer, List<Showtime>> getShowtimesGrouped(){
		Map<Integer, List<Showtime>> map = new HashMap<Integer, List<Showtime>>();

		List<Showtime> all = repo.findAll();
		for (Showtime s: all) {
			if (map.get(s.getMovieId()) == null) {
				map.put(s.getMovieId(), new ArrayList<Showtime>());
			}
			map.get(s.getMovieId()).add(s);
		}
		return map;
			
	}

	public Map<Integer, List<Showtime>> getShowtimesGroupedAt(int id){
		Map<Integer, List<Showtime>> map = new HashMap<Integer, List<Showtime>>();

		List<Showtime> all = getShowtimesByLocation(id);
		for (Showtime s: all) {
			if (map.get(s.getMovieId()) == null) {
				map.put(s.getMovieId(), new ArrayList<Showtime>());
			}
			map.get(s.getMovieId()).add(s);
		}
		return map;
			
	}
	public String deleteShowtime(int id) {
		if(!repo.findById(id).isPresent()) {
			return "Showtime not found";
		}
		else {
			repo.deleteById(id);
			return "Showtime deleted";
		}
	}
	
}
