package com.controller;

import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.entity.Showtime;
import com.google.common.base.Optional;
import com.repository.ShowtimeRepository;
import com.service.ShowtimeService;

@RestController
@RequestMapping("/api/showtime/")
//@CrossOrigin("*")
@RefreshScope
public class ShowtimeController {
	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS");
	@Autowired
	private ShowtimeRepository repo;
	@Autowired
	private ShowtimeService service;

	@GetMapping("/getshowtimes")
	public List<Showtime> getShowtimes(){
		return repo.findAll();
	}

	@GetMapping("/getshowtimesgrouped")
	public Map<Integer, List<Showtime>> getShowtimesGrouped(){
		return service.getShowtimesGrouped();
	}

	@GetMapping("/getshowtimesgroupedat/{id}")
	public Map<Integer, List<Showtime>> getShowtimesGroupedAt(@PathVariable int id){
		return service.getShowtimesGroupedAt(id);
	}
	
	@PostMapping("/addshowtime")
	public Showtime addShowtime(@RequestBody Showtime showtime) {
		return repo.save(showtime);
	}
	@GetMapping("/getshowtimes/{id}")
	public List<Showtime> getShowtimesByLocation(@PathVariable int id){
		return service.getShowtimesByLocation(id);
	}

	@GetMapping("/getshowtime/{id}")
	public Showtime getUser(@PathVariable int id) {
		java.util.Optional<Showtime> st = repo.findById(id);
		if (st.isPresent())
			return st.get();
		return null;
		
	}
	
	@DeleteMapping("/deleteshowtime/{id}")
	public String deleteShowtime(@PathVariable int id) {
		return service.deleteShowtime(id);
	}

	@DeleteMapping("/deleteall")
	public void deleteShowtimes() {
		repo.deleteAll();
	}
	@PutMapping("/updateshowtime")
	public Showtime updateShowtime(@RequestBody Showtime showtime) {
		return repo.save(showtime);
	}
}
