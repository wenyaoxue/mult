package com.example.Multiplex;

import static org.junit.Assert.assertEquals;

import java.time.LocalDateTime;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.controller.ShowtimeController;
import com.entity.Showtime;
import com.service.ShowtimeService;

@SpringBootTest
class MultiplexApplicationTests {
	@Autowired
	ShowtimeController controller;
	@Autowired
	ShowtimeService service;
	public static Showtime s1;
	public static Showtime s2;
	
	@BeforeAll
	public static void setUp() {
		s1 = new Showtime(100, 52, 73, LocalDateTime.now(), 150, (float)91.71);
	}
	@Test
	void testAdd() {
		int datasize = controller.getShowtimes().size();
		controller.addShowtime(s1);
		assertEquals(controller.getShowtimes().size(), datasize + 1);
		int sId = 0;
		for(Showtime s : controller.getShowtimes()) {
			if(s.getPrice() == (float)91.71) {
				sId = s.getShowtimeId();
			}
		}
		controller.deleteShowtime(sId);
	}
	@Test
	void updateShowtime() {
		controller.addShowtime(s1);
		int sId = 0;
		for(Showtime s : controller.getShowtimes()) {
			if(s.getPrice() == (float)91.71) {
				sId = s.getShowtimeId();
			}
		}
		controller.updateShowtime(new Showtime(sId, s1.getMovieId(), s1.getMultiplexId(), s1.getTime(), 151, s1.getPrice()));
		Showtime updated = new Showtime();
		for(Showtime s : controller.getShowtimes()) {
			if(s.getPrice() == (float)91.71) {
				updated = s;
			}
		}
		assertEquals(updated.getRemainderTix(), 151);
		controller.deleteShowtime(sId);
	}
}
