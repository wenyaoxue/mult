package com.example.Multiplex;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.controller.OfferController;
import com.entity.Offer;
import com.service.OfferService;



@SpringBootTest
class MultiplexApplicationTests {

	@Autowired
	OfferService service;
	@Autowired 
	OfferController controller;
	public static Offer o1;
	
	@BeforeAll
	public static void setUp() {
		o1 = new Offer(900, 80, "sampleOffer");
	}
	@Test
	void testAdd() {
		int dataSize = controller.getOffers().size();
		controller.addOffer(o1);
		assertEquals(controller.getOffers().size(), dataSize + 1);
		int offerId = 0;
		for(Offer o : controller.getOffers()) {
			if(o.getText().equals("sampleOffer")) {
				offerId = o.getOfferId();
			}
		}
		controller.deleteOffer(offerId);
	}
	@Test
	void testUpdate() {
		controller.addOffer(o1);
		int offerId = 0;
		for(Offer o : controller.getOffers()) {
			if(o.getText().equals("sampleOffer")) {
				offerId = o.getOfferId();
			}
		}
		controller.updateOffer(new Offer(offerId, o1.getAmount(), "sampleOffer1"));
		controller.deleteOffer(offerId);
	}
}
