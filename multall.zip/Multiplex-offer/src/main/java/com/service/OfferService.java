package com.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.repository.OfferRepository;

@Service
public class OfferService {
	@Autowired
	private OfferRepository repo;

	public String deleteOffer(int id) {
		if(!repo.findById(id).isPresent()) {
			return "Offer not found";
		}
		else {
			repo.deleteById(id);
			return "Offer deleted";
		}
	}

	

	
	
	

	
}
