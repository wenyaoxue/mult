package com.example.Multiplex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultiplexApplicationTests {

	@Test
	void contextLoads() {
	}

}
