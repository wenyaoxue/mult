package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.entity.Movie;
import com.repository.MovieRepository;
import com.service.MovieService;

@RestController
@RequestMapping("/api/movies")
@CrossOrigin("*")
@RefreshScope
public class MovieController {
	@Autowired
	private MovieRepository repo;
	@Autowired
	private MovieService service;

		
		@GetMapping("/allmovies")
		public List<Movie> getAllMovies() {
			List<Movie> ml = repo.findAll();
			System.out.println(ml);
			return repo.findAll();
		}
		@GetMapping("/getmovie/{id}")
		public Movie getMovie(@PathVariable int id) {
			return repo.findById(id).get();
		}
		@PostMapping("/addmovie")
		public Movie addMovie(@RequestBody Movie movie) {
			return repo.save(movie);
		}
		@DeleteMapping("/deletemovie/{id}")
		public String deleteMovie(@PathVariable int id) {
			return service.deleteMovie(id);
		}
		@PutMapping("/updatemovie")
		public Movie updateMovie(@RequestBody Movie movie) {
			return repo.save(movie);
		}
}
