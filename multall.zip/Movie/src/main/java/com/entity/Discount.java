package com.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Table(name = "discount")
@Data
//@NoArgsConstructor
//@AllArgsConstructor
@ToString
public class Discount {
	@Id
	@GeneratedValue
	private int discountId;
	private double amount;
	private String text;
	
	
	
	public int getDiscountId() {
		return discountId;
	}



	public void setDiscountId(int discountId) {
		this.discountId = discountId;
	}



	public double getAmount() {
		return amount;
	}



	public void setAmount(double amount) {
		this.amount = amount;
	}



	public String getText() {
		return text;
	}



	public void setText(String text) {
		this.text = text;
	}
	


	public Discount(int discountId, double amount, String text) {
		super();
		this.discountId = discountId;
		this.amount = amount;
		this.text = text;
	}



	public Discount() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
}
