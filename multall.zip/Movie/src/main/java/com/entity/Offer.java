package com.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Table(name = "discount")
@Data
//@NoArgsConstructor
//@AllArgsConstructor
@ToString
public class Offer {
	@Id
	@GeneratedValue
	private int offerId;
	private int amount;
	private String text;
	
	
	public int getOfferId() {
		return offerId;
	}


	public void setOfferId(int offerId) {
		this.offerId = offerId;
	}


	public int getAmount() {
		return amount;
	}


	public void setAmount(int amount) {
		this.amount = amount;
	}


	public String getText() {
		return text;
	}


	public void setText(String text) {
		this.text = text;
	}

	
	public Offer(int offerId, int amount, String text) {
		super();
		this.offerId = offerId;
		this.amount = amount;
		this.text = text;
	}


	public Offer() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
}
