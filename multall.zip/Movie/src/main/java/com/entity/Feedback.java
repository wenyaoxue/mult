package com.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Table(name = "feedback")
@Data
//@NoArgsConstructor
//@AllArgsConstructor
@ToString
public class Feedback {
	@Id
	@GeneratedValue
	private int feedbackId;
	private String type;
	private String message;
	private String resolved;
	public int getFeedbackId() {
		return feedbackId;
	}
	public void setFeedbackId(int feedbackId) {
		this.feedbackId = feedbackId;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getResolved() {
		return resolved;
	}
	public void setResolved(String resolved) {
		this.resolved = resolved;
	}
	public Feedback(int feedbackId, String type, String message, String resolved) {
		super();
		this.feedbackId = feedbackId;
		this.type = type;
		this.message = message;
		this.resolved = resolved;
	}
	public Feedback() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
}
