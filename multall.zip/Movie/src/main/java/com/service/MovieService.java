package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.Movie;
import com.repository.MovieRepository;

@Service
public class MovieService {
	@Autowired
	private MovieRepository repo;

	public String deleteMovie(int id) {
		if(!repo.findById(id).isPresent()) {
			return "Movie not found";
		}
		else {
			repo.deleteById(id);
			return "Movie deleted";
		}
	}
	
	

	
}
